import matplotlib.pylab as plt
import numpy as np
import pandas as pd

data = pd.read_csv('AAPL.csv')[::-1]
close_price = data.ix[:, 'Adj Close'].tolist()
plt.plot(close_price)
plt.show()