import numpy as np
import time

"""
1) Load data
2) Form input arrays
2.5) Normalize data if necessary
3) Create network
4) Learn network
5) Test network
6) Estimate network quality
"""

"""Globals"""
global_start_time = time.time()
epochs = 1
seq_len = 50
is_normalise_window = True


def normalise_windows(window_data):
    normalised_data = []
    for window in window_data:
        normalised_window = [((float(p) / float(window[0])) - 1) for p in window]
        normalised_data.append(normalised_window)
    return normalised_data

""" Write straightforward with no functions """
""" Stage 1 - Load data """
f = open('sinwave.csv', 'rb').read()
data = f.decode().split('\n')
sequence_length = seq_len + 1
result = []

for index in range(len(data) - sequence_length):
    result.append(data[index: index + sequence_length])

if is_normalise_window:
    result = normalise_windows(result)

result = np.array(result)

row = round(0.9 * result.shape[0])
train = result[:int(row), :]
np.random.shuffle(train)
x_train = train[:, :-1]
y_train = train[:, -1]
x_test = result[int(row):, :-1]
y_test = result[int(row):, -1]

x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))
x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

# return [x_train, y_train, x_test, y_test]




